<?php
include "token.php";
     $tokenn = "684895949:AAFL1gvWkA0zfO1t4UOntyX3P74zu5g7rLY";
     $gpid = -1001170823256; 
     $send = file_get_contents("https://api.telegram.org/bot$tokenn/SendMessage?chat_id=$gpid&text=".urlencode($textmsg));
?>