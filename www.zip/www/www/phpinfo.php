<?php 
   echo phpinfo();  
?>